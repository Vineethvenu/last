class ApiEndPoints {
  static const String baseURL = 'https://trogon.info/interview/php/api';
  static const String subject = "/subjects.php";
  static const String subId='https://trogon.info/interview/php/api/modules.php?subject_id=';
  static const String moduleId='https://trogon.info/interview/php/api/videos.php?module_id=';
}
