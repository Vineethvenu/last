import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../../../core/helpers/routes/app_route_path.dart';
import '../../../core/utils/config/styles/colors.dart';
import '../../../core/utils/shared/constant/assets_path.dart';

class PaymentsProvider extends ChangeNotifier {
  PaymentsProvider() {
    loadingPayments();
  }

  // Loading state
  bool _isLoading = false;
  bool get isLoading => _isLoading;

  int _curIndex = 0;
  int get curIndex => _curIndex;

  // Payment items
  final List<Map<String, dynamic>> _paymentsItems = [
    {
      "logo": AssetsPath.reinitiate,
      "title": "Re-initiate",
      'route': RoutesPath.re_initiate,
      "cardColor": AppColor.card1,
      "cardTitle": AppColor.card1Title
    },
    {
      "logo": AssetsPath.request,
      "title": "Re-initiate Successful\nPayment - Request",
      'route': RoutesPath.re_request,
      "cardColor": AppColor.card2,
      "cardTitle": AppColor.card2Title
    },
    {
      "logo": AssetsPath.approval,
      "title": "Re-initiate Successful\nPayment - Approval",
      'route': RoutesPath.re_approval,
      "cardColor": AppColor.card3,
      "cardTitle": AppColor.card3Title
    },
    {
      "logo": AssetsPath.debitAdvice,
      "title": "Debit advise block",
      'route': RoutesPath.debitAdvise,
      "cardColor": AppColor.card4,
      "cardTitle": AppColor.card4Title
    },
    {
      "logo": AssetsPath.succesDebitAdvice,
      "title": "Successful payment\nto debit advise",
      'route': RoutesPath.paymentDebitAdvise,
      "cardColor": AppColor.card5,
      "cardTitle": AppColor.card5Title
    },
    {
      "logo": AssetsPath.changeDebitAdvice,
      "title": "Change debit advise branch",
      'route': RoutesPath.changeDebitAdviseBranch,
      "cardColor": AppColor.card6,
      "cardTitle": AppColor.card6Title
    },
    {
      "logo": AssetsPath.bank,
      "title": "Change branch IMPS bank",
      'route': RoutesPath.changeBranchImpsBank,
      "cardColor": AppColor.card7,
      "cardTitle": AppColor.card7Title
    },
    {
      "logo": AssetsPath.pending,
      "title": "Bulk reinitiate debit\nadvise pending",
      'route': RoutesPath.bulkReinitiate,
      "cardColor": AppColor.card8,
      "cardTitle": AppColor.card8Title
    }
  ];

  // Report items
  final List<Map<String, dynamic>> _reportItem = [
    {
      "logo": AssetsPath.request,
      "title": "Payments report",
      'route': RoutesPath.paymentReport,
      "cardColor": AppColor.card1,
      "cardTitle": AppColor.card1Title
    },
    {
      "logo": AssetsPath.gold,
      "title": "Payment OGL report",
      'route': RoutesPath.paymentOglReport,
      "cardColor": AppColor.card2,
      "cardTitle": AppColor.card2Title
    },
    {
      "logo": AssetsPath.daReport,
      "title": "Debit advise report",
      'route': RoutesPath.paymentDebitAdviseReport,
      "cardColor": AppColor.card3,
      "cardTitle": AppColor.card3Title
    },
    {
      "logo": AssetsPath.status,
      "title": "Payment status",
      'route': RoutesPath.paymentStatus,
      "cardColor": AppColor.card4,
      "cardTitle": AppColor.card4Title
    },
    {
      "logo": AssetsPath.inquiry,
      "title": "IMPS Inquiry",
      'route': RoutesPath.impsInquiry,
      "cardColor": AppColor.card5,
      "cardTitle": AppColor.card5Title
    },
    {
      "logo": AssetsPath.debitAdvice,
      "title": "Customer NEFT Details",
      'route': RoutesPath.neftDeatils,
      "cardColor": AppColor.card6,
      "cardTitle": AppColor.card6Title
    },
  ];

  List<Map<String, dynamic>> get paymentsItems => _paymentsItems;
  List<Map<String, dynamic>> get reportItem => _reportItem;

  List<Map<String, dynamic>> _filteredItems = [];
  List<Map<String, dynamic>> get filteredItems => _filteredItems;

  Future<void> loadingPayments() async {
    _isLoading = true;
    notifyListeners();

    await Future.delayed(const Duration(seconds: 2)).then((value) {
      _isLoading = false;
      loadPaymentsItem();
      notifyListeners();
    });
  }

  setTabIndex(int index) async {
    _curIndex = index;
    if (_curIndex == 0) {
      loadPaymentsItem();
    } else {
      loadReportItem();
    }
    notifyListeners();
  }

  void searchItems(String query) {
    List<Map<String, dynamic>> sourceList =
        _curIndex == 0 ? paymentsItems : reportItem;

    if (query.isEmpty) {
      _filteredItems = List.from(sourceList);
    } else {
      _filteredItems = sourceList
          .where((item) => item['title']
              .toString()
              .toLowerCase()
              .contains(query.toLowerCase()))
          .toList();
    }
    notifyListeners();
  }

  void loadPaymentsItem() {
    _filteredItems = List.from(paymentsItems);
    notifyListeners();
  }

  void loadReportItem() {
    _filteredItems = List.from(reportItem);
    notifyListeners();
  }
}
