package com.mafil_payment_app.payments_application

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
